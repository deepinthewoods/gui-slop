Frame Patch Lab export
======================

Files in this archive:
  <image>.processed.png   The full keyed/inpainted sheet. Use THIS as the
                          texture in Godot — MultiPatchFrame indexes into it
                          via each frame's sourceRect.
  <image>.<frame>.png     One cropped PNG per detected frame (raw images, not
                          needed by MultiPatchFrame which uses the sheet).
  <image>.patches.json    Every frame's patch data ({ frames: [ ... ] }).

Godot usage:
  1. Copy MultiPatchFrame.gd (and MultiPatchFrameLoader.gd) into your project.
  2. Import <image>.processed.png and <image>.patches.json.
  3. var data = MultiPatchFrameLoader.load_patches("res://.../<image>.patches.json")
     var sheet = load("res://.../<image>.processed.png")
     var frame = MultiPatchFrameLoader.make_frame_by_name(sheet, data, "Frame 1")
     frame.size = Vector2(300, 120)
     add_child(frame)

See README.md in the Frame Patch Lab repo for full details.
